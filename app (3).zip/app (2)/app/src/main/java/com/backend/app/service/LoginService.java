package com.backend.app.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import com.backend.app.model.Login;
import com.backend.app.repository.LoginRepo;

import java.util.Optional;

@Service
public class LoginService {
    @Autowired
    private LoginRepo repo;

    public Login createLogin(Login login) {
        return repo.save(login);
    }

    public Page<Login> getAllLogins(Pageable pageable) {
        return repo.findAll(pageable);
    }

    public Optional<Login> getLoginById(Integer loginId) {
        return repo.findById(loginId);
    }

    public Login updateLogin(Integer loginId, Login updatedLogin) {
        Optional<Login> optionalLogin = repo.findById(loginId);
        if (optionalLogin.isPresent()) {
            Login login = optionalLogin.get();
            login.setUsername(updatedLogin.getUsername());
            login.setPassword(updatedLogin.getPassword());
            // Update other fields as needed
            return repo.save(login);
        }
        return null;
    }

    public void deleteLogin(Integer loginId) {
        repo.deleteById(loginId);
    }
}