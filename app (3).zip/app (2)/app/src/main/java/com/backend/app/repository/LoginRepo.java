package com.backend.app.repository;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;


import com.backend.app.model.*;
@Repository
public interface LoginRepo extends JpaRepository<Login,Integer>{
}